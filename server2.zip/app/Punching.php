<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Punching extends Model
{
    //
}

