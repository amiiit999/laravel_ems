<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card-panel grey-text text-darken-2 mt-20">
            <h4 class="grey-text text-darken-1 center">Employee Details</h4>
            <div class="row">
                <div class="row collection mt-20">
                    <!-- Show this image on small devices -->
                    <div class="hide-on-med-only hide-on-large-only row">
                        <div class="col s8 offset-s2 mt-20">
                            <img class="p5 card-panel emp-img-big" src="<?php echo e($employee->picture); ?>">
                        </div>
                    </div>
                    <div class="col m8 l8 xl8">
                        <h5 class="pl-15 mt-20"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></h5>
                
                        <p class="pl-15"><i class="material-icons left">perm_identity</i><?php echo e($employee->empDepartment->dept_name); ?>, <?php echo e($employee->empDesignation->emp_designation); ?></p>
                           
              
                        <?php if(count($leaves)>0): ?>
                      <?php $__currentLoopData = $leaves->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <p class="pl-15 mt-20"><i class="material-icons left">calendar_today</i> <?php echo e($leave->month); ?></p>
                        <p class="pl-15 mt-20"><i class="material-icons left">how_to_reg</i>LEAVE(S) - <?php echo e($leave->leaves); ?></p>
                        <p class="pl-15 mt-20"><i class="material-icons left">access_time</i>09:40 - <?php echo e($leave->late_coming1); ?></p>
                        <p class="pl-15 mt-20"><i class="material-icons left">access_time</i>10:30 - <?php echo e($leave->late_coming2); ?></p>
                        <p class="pl-15 mt-20"><i class="material-icons left">access_time</i>Short Break - <?php echo e($leave->short_break); ?></p>
                         
                       
                    </div>

                    <!-- Hide this image on small devices -->
                    <div class="hide-on-small-only col m4 l4 xl3">
                        <img class="p5 card-panel emp-img-big" src="<?php echo e($employee->picture); ?>">
                    </div>
                    
                     <a class="btn blue col s3 offset-s2 m3 offset-m2 l3 offset-l2 xl3 offset-xl2" href='<?php echo e(url("leavesedit/$employee->id")); ?>'>Update</a>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                      <a class="btn blue col s3 offset-s2 m3 offset-m2 l3 offset-l2 xl3 offset-xl2" href=
                      '<?php echo e(url("add_leaves/$employee->id")); ?>'>Add Leave</a>
                      <br>
                       <br>

                    <?php endif; ?>
                </div>
                     <?php if(count($punchings)>0): ?>
                      
                <div class="collection">
                    
                    
                     <div class="container">
    
        
            <table >
                <tbody>
                    <tr>
                        <th>ID:</th>
                       
                        <th>DATE:</th>
                         <th>DAY:</th>
                        <th>PUNCH IN:</th>
                        <th>PUNCH OUT:</th>
                         <th>UPDATE:</th>
                        

                    </tr>

                    <?php else: ?>
                      <a class="btn green col s3 offset-s2 m3 offset-m2 l3 offset-l2 xl3 offset-xl2" href=' <?php echo e(url("attendence_create/$employee->id")); ?>'
                                    >mark attedence</a>

  <?php endif; ?> 
  

                    
                    
                    <?php if(count($punchings)>0): ?>
                      <?php $__currentLoopData = $punchings->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $punching): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($punching->id); ?></td>
                         
                            <td><?php echo e($punching->date); ?></td>
                               <td><?php echo e($punching->day); ?></td>
                            <td><?php echo e($punching->punch_in); ?></td>
                            <td><?php echo e($punching->punch_out); ?></td>
                           <td>  <a class="btn green" href="<?php echo e(route('attendence.edit',$punching->id)); ?>">Update</a></td>
                           
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php endif; ?>
                </tbody>
            </table>
        
   

                    
                    
                   
                </div>
                <br>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>