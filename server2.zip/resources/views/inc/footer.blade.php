<footer class="page-footer gradient-bg">
    <div class="footer-copyright">
        <div class="container">
           Designed & Developed by Mr. amiit
        </div>
    </div>
</footer>